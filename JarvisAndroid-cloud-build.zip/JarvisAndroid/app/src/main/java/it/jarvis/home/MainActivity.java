package it.jarvis.home;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 41;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private TextView status, answer;
    private Button talk;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        answer = findViewById(R.id.answer);
        talk = findViewById(R.id.talk);
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(Locale.ITALIAN);
        });
        talk.setOnClickListener(v -> beginTalk());
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("RICONOSCIMENTO VOCALE NON DISPONIBILE");
            talk.setEnabled(false);
        }
    }

    private void beginTalk() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new android.speech.RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { status.setText("TI ASCOLTO"); }
            public void onBeginningOfSpeech() { status.setText("IN ASCOLTO…"); }
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { status.setText("ELABORAZIONE"); }
            public void onError(int e) { status.setText("PRONTO · RIPROVA"); }
            public void onResults(Bundle b) {
                ArrayList<String> results = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (results == null || results.isEmpty()) { status.setText("NON HO CAPITO"); return; }
                String said = results.get(0);
                answer.setText("Hai detto: «" + said + "»\n\nLa connessione al cervello AI sarà aggiunta nella prossima fase.");
                status.setText("PRONTO");
                if (tts != null) tts.speak("Ho capito. Hai detto: " + said, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int t, Bundle p) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Parla con JARVIS");
        recognizer.startListening(i);
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
