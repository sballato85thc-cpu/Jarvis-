# JARVIS — prototipo Android 0.1

Questo archivio contiene il **codice sorgente** del prototipo iniziale, non un APK già installabile.

## Cosa fa questa build
- Mostra una schermata HUD scura/blu con il nome JARVIS.
- Chiede il permesso microfono.
- Avvia il riconoscimento vocale italiano quando si tocca il pulsante.
- Legge ad alta voce una conferma con la sintesi vocale Android.

## Cosa NON fa ancora
Non contiene ancora parola di attivazione sempre in ascolto, conversazione AI, memoria, voce britannica dedicata, servizio in background o riavvio automatico. Non è ancora l'assistente domestico descritto nel progetto.

## Ottenere un APK usando solo il telefono
È incluso un workflow GitHub Actions che può compilare il progetto nel cloud. Non serve un PC, ma serve un account GitHub e il browser del telefono.

1. Dal telefono, apri GitHub e crea un account gratuito, se non ne hai già uno.
2. Crea un nuovo repository, ad esempio `jarvis-android`.
3. Carica **il contenuto** di questa cartella nel repository (non caricare soltanto lo ZIP come singolo file). Assicurati che la cartella `.github/workflows` e il file `build-apk.yml` siano inclusi.
4. Apri la scheda **Actions** del repository e seleziona **Build JARVIS APK**.
5. Premi **Run workflow** e attendi che il lavoro termini con esito verde.
6. Apri il risultato della compilazione, vai in **Artifacts** e scarica `JARVIS-debug-APK`.
7. Estrai lo ZIP scaricato: troverai `app-debug.apk`. Aprilo sul WP5 e autorizza l'installazione da quella sorgente, se Android lo richiede.

Il workflow produce un APK di debug per prove personali, non una versione pronta per Google Play. Mantieni il repository privato se non vuoi rendere pubblico il codice.

## Requisiti tecnici
- Android minimo: 10 (API 29).
- Build cloud: Java 17, Gradle 8.9, Android SDK 35.

## Prossime fasi
1. Integrare un motore wake-word locale e verificarne licenza/costi.
2. Implementare un foreground service con notifica persistente, permessi e gestione batteria.
3. Collegare un backend AI sicuro: la chiave API non deve essere inserita nell'APK.
4. Integrare riconoscimento e sintesi vocale di qualità.
5. Testare stabilità, consumi, temperatura e privacy sul WP5.
